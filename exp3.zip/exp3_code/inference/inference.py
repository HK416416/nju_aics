import numpy as np
import os
from typing import Any, Generator, List,Tuple,Dict
from threading import Lock
from session import Session
from config import InferenceConfig

class LlamaInterface:
    def __init__(self,config:InferenceConfig) -> None:
        self.max_length = config.max_length
        from transformers import AutoTokenizer
        self.tokenizer=AutoTokenizer.from_pretrained(config.tokenizer)
        self.sampling_method=config.sampling_method
        self.sampling_value = config.sampling_value
        self.temperature=config.temperature
        self.session=Session.fromConfig(config)
        self.prompt=config.prompt
        self.state:dict[str,Any] = {"code":200,"isEnd":False,"message":""}        
        self.first=True
        self.stop_mp = {"[|Human|]":6,"[|AI|]":5,"<|assistant|>":6,"<|user|>":5,"<|system|>":5}
        self.stop_words = ["<|user|>","<|assistant|>","<|system|>","[|AI|]","[|Human|]"]
        self.model_type = config.model_type
        self.last_output=""
        self.lock = Lock()
        self.reset()
        print("init success")

    def generate_cache(self,prompt:str):
        # 生成缓存
        if len(prompt) == 0 :
            return
        input_ids = np.asarray(self.encode(prompt,add_bos_token=self.first),dtype=np.int64).reshape(1,-1)
        self.first = False
        logits, _, _ = self.session.run(input_ids)
        return self.sample_logits_top_k(logits[0][-1:],self.sampling_value,self.temperature),logits

    def sample_logits_top_k(
        self,
        logits: np.ndarray,
        sampling_value: float = None,
        temperature: float = 1.0,
    ) -> np.ndarray:
        logits = logits.astype(np.float32)
        # TODO: 只在概率最高的前 k 个 tokens 中加权采样
        top_k = int(sampling_value) 
        if temperature <= 0:
            raise ValueError("Temperature must be positive")
        
        if top_k <= 0 or top_k > len(logits):
            top_k = len(logits)
        
        # 应用温度参数
        if temperature > 0:
            logits = logits / temperature
        
        # 数值稳定的softmax
        max_logit = np.max(logits)
        logits = logits - max_logit
        exp_logits = np.exp(logits)
        probs = exp_logits / np.sum(exp_logits)
        
        # Top-k采样
        if top_k < len(probs):
            top_k_indices = np.argpartition(probs, -top_k)[-top_k:]
            top_k_probs = probs[top_k_indices]
            top_k_probs = top_k_probs / np.sum(top_k_probs)
            sampled_token_id = np.random.choice(top_k_indices, p=top_k_probs)
        else:
            sampled_token_id = np.random.choice(len(probs), p=probs)
        
        return np.array([sampled_token_id])
        
        
        

    
    def format_last_output(self):
        if len(self.last_output) == 0:
            return 
        text_format = self.apply_chat_template([{"role":"assistant","content":self.last_output}])
        self.generate_cache(text_format[len(self.last_output):])
        self.last_output = ""
    
    def predict(self, text):
        if text == "":
            return
        self.format_last_output()
        if hasattr(self, 'apply_chat_template'):
            messages = [{"role": "user", "content": text}]
            prompt = self.apply_chat_template(messages)
        else:
            prompt = text  # 回退到直接使用文本
        
        # 编码输入
        input_ids = self.encode(prompt)
        
        # 初始化生成参数
        generated_tokens = []
        max_length = getattr(self, 'max_length', 512)
        
        # 获取EOS token
        eos_token_id = self.tokenizer.eos_token_id
        
        # 自回归生成
        for step in range(max_length):
            # 模型推理
            outputs = self.session.run(input_ids)
            
            # 安全获取logits
            if isinstance(outputs, dict):
                logits = outputs.get("logits", None)
                if logits is None:
                    # 尝试其他可能的键名
                    for key in ['output_0', 'output']:
                        if key in outputs:
                            logits = outputs[key]
                            break
            elif isinstance(outputs, (list, tuple)) and len(outputs) > 0:
                logits = outputs[0]
            else:
                logits = outputs
            
            if logits is None:
                raise ValueError("无法从模型输出中获取logits")
            
            # 采样下一个token
            next_token_logits = logits[0, -1, :]
            next_token = self.sample_logits_top_k(next_token_logits)
            next_token_id = next_token[0]
            
            # 检查停止条件
            should_stop = False
            if next_token_id == eos_token_id:
                should_stop = True
            elif hasattr(self, 'stop_mp') and next_token_id in self.stop_mp:
                should_stop = True
            
            # 处理停止条件
            if should_stop:
                if hasattr(self.session, 'rollback'):
                    self.session.rollback()
                break
            
            # 更新状态
            generated_tokens.append(next_token_id)
            input_ids = next_token.reshape(1, 1)  # 保持正确的形状
            
            # 更新first标志
            if hasattr(self, 'first') and self.first:
                self.first = False
        
        # 解码并保存结果
        response = self.decode(generated_tokens)
        self.last_output = response
        
        return response

    def reset(self):
        self.first = True
        self.last_output = ""
        self.session.reset()
        self.generate_cache(self.apply_chat_template(self.prompt))
        
    def getState(self):

        if hasattr(self, 'state'):
            with self.lock:
                return self.state.copy()
        else:
            return {"status": "state_not_implemented"}
        # with self.lock:
        #     return self.state.copy()
        #return NotImplementedError()


    def apply_chat_template(self,messages:List[Dict[str,str]]) -> str:
        # TODO: 实现聊天模板，prompt 有三种类型的角色，请参考下面的格式进行实现，输出为
        #
        # 格式参考:
        # https://huggingface.co/docs/transformers/main/en/chat_templating
        #
        # 输入样例:
        # messages = [
        #     {
        #         "role": "system",
        #         "content": "You are a friendly chatbot who always responds in the style of a pirate",
        #     },
        #     {   "role": "user",
        #          "content": "How many helicopters can a human eat in one sitting?"
        #     },
        #     {   "role": "assistant",
        #          "content": "I do not know!"
        #     },
        # ]
        #
        # 输出样例:
        # """
        # <|system|> # 注意这里到下一行需要使用换行符 \n 进行换行
        # You are a friendly chatbot who always responds in the style of a pirate</s>
        # <|user|>
        # How many helicopters can a human eat in one sitting?</s>
        # <|assistant|>
        # I do not know!</s>
        # """
        #
        # 注意，如果最后一条消息是用户消息，则生成的文本以 <|assistant|> 结尾，表示模型需要生成回复
        #
        if not messages:
            return ""
        
        prompt_parts = []
        
        for message in messages:
            # 验证消息格式
            if "role" not in message or "content" not in message:
                continue
                
            role = message["role"]
            content = message["content"].strip()
            
            # 跳过空内容
            if not content:
                continue
                
            if role == "system":
                prompt_parts.append(f"<|system|>\n{content}</s>")
            elif role == "user":
                prompt_parts.append(f"<|user|>\n{content}</s>")
            elif role == "assistant":
                prompt_parts.append(f"<|assistant|>\n{content}</s>")
            else:
                prompt_parts.append(f"<|{role}|>\n{content}</s>")
        
        # 如果最后是用户消息，添加assistant开始标记
        if messages and messages[-1].get("role") == "user":
            prompt_parts.append("<|assistant|>")
        
        # 用换行符连接，避免开头或结尾有多余换行
        prompt = "\n".join(prompt_parts)
        return prompt
    
    def encode(self,text,add_bos_token=False):
        self.tokenizer.add_bos_token = add_bos_token
        return self.tokenizer.encode(text)

def is_stop_word_or_prefix(s: str, stop_words: list) -> int:
    for stop_word in stop_words:
        if s.endswith(stop_word):
            return stop_word
    return ""