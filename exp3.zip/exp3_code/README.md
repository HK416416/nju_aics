
```
exp3_code
├─ export_llama
│  ├─ config
│  │  ├─ no.py
│  │  ├─ w8.py
│  │  ├─ w8x8.py
│  │  └─ __pycache__
│  │     └─ w8x8.cpython-39.pyc
│  ├─ export_llama.py
│  ├─ generate_act_scales.py
│  ├─ quantize.py
│  ├─ requirement_act.txt
│  └─ requirement_export.txt
├─ inference
│  ├─ config.py
│  ├─ engine.py
│  ├─ inference.py
│  ├─ kvcache.py
│  ├─ main.py
│  ├─ README.md
│  ├─ requirements.txt
│  └─ session.py
└─ README.md

```