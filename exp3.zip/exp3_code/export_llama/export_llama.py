import argparse
import importlib
import torch
import os
from transformers import LlamaForCausalLM, LlamaTokenizer
import quantize


def export_onnx(base_model,out_path,quant_cfg_path,act_path):
    tokenizer = LlamaTokenizer.from_pretrained(base_model)
    device = "cpu"
    model = LlamaForCausalLM.from_pretrained(
        base_model,
        torch_dtype=torch.float32,
        device_map="auto",
    ).to(device)
    model_cfg=model.model.config

    print("Model configuration:")
    print(f"  hidden_size: {model_cfg.hidden_size}")
    print(f"  num_attention_heads: {model_cfg.num_attention_heads}")
    print(f"  num_hidden_layers: {model_cfg.num_hidden_layers}")
    print(f"  num_key_value_heads: {getattr(model_cfg, 'num_key_value_heads', model_cfg.num_attention_heads)}")


    spec = importlib.util.spec_from_file_location("quant_cfg_module", quant_cfg_path)
    quant_cfg_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(quant_cfg_module)
    quantize_cfg = quant_cfg_module.get(model_cfg,act_path)
    from quantize import quantize
    quantize(model,quantize_cfg)
    
    input_names = ["input_ids", "attention_mask", "position_ids","past_key_values"]
    output_names = ["logits","out_key_values","attn_scores"]
    
    batch_size,seq_len,kv_len=1,1,1024 # 请勿修改

    # TODO: 构造导出假输入，需要和模型实际输入对应上
    # input_ids 形状为 (batch_size, sequence_length)
    # attention_mask 形状为 (batch_size, all_sequence_length(what's that?))
    # position_ids 形状为 (batch_size, sequence_length)
    # past_key_values 形状为 (n_layers, 2, batch_size, n_heads, kv_len, head_dim)
    
    ##
    n_layers = model_cfg.num_hidden_layers
    n_heads = model_cfg.num_attention_heads  
    num_key_value_heads = getattr(model_cfg, 'num_key_value_heads', n_heads)
    head_dim = model_cfg.hidden_size // n_heads

    print(f"Using GQA configuration: {n_heads} query heads, {num_key_value_heads} key/value heads")
    
    # 构造输入张量
    input_ids = torch.ones(batch_size, seq_len, dtype=torch.long)
    attention_mask = torch.ones(batch_size, seq_len + kv_len, dtype=torch.long)
    
    position_ids = torch.arange(seq_len, dtype=torch.long).unsqueeze(0)
    
    # past_key_values: (n_layers, 2, batch_size, n_heads, kv_len, head_dim)
    past_key_values = []
    for i in range(n_layers):
        # 每个层有两个张量：past_key 和 past_value
        past_key = torch.zeros(batch_size, num_key_value_heads, kv_len, head_dim, dtype=torch.float32)
        past_value = torch.zeros(batch_size, num_key_value_heads, kv_len, head_dim, dtype=torch.float32)
        past_key_values.append((past_key, past_value))
    
    input_args = {
        'input_ids': input_ids,
        'attention_mask': attention_mask, 
        'position_ids': position_ids,
        'past_key_values': past_key_values,
        'use_cache': True,  # 必须为 True 才能输出 past_key_values
        'output_attentions': True,  # 输出注意力分数
        'return_dict': True 
    }

    dynamic_axes = {
        "input_ids": {0: "batch_size", 1: "seq_length"},
        "attention_mask": {0: "batch_size", 1: "all_sequence_length"},
        "position_ids": {0: "batch_size", 1: "seq_length"},
        # past_key_values 是元组列表，不是单个张量，所以不能直接设置动态轴
        "logits": {0: "batch_size", 1: "seq_length"},
        # out_key_values 也是元组列表，不能直接设置动态轴
    }

    print("Testing forward pass...")
    model.eval()
    #raise NotImplementedError("Please complete the TODOs in export_onnx function before running.")
    try:
        with torch.no_grad():
            output = model(
                input_ids, 
                attention_mask=attention_mask, 
                position_ids=position_ids, 
                past_key_values=past_key_values
            )
        print("✅ Forward pass test successful")
        print(f"Output logits shape: {output.logits.shape}")
        if hasattr(output, 'past_key_values') and output.past_key_values is not None:
            print(f"Output past_key_values length: {len(output.past_key_values)}")
            if len(output.past_key_values) > 0:
                print(f"First layer key shape: {output.past_key_values[0][0].shape}")
                print(f"First layer value shape: {output.past_key_values[0][1].shape}")
    except Exception as e:
        print(f"❌ Forward pass test failed: {e}")
        print("Input shapes:")
        print(f"  input_ids: {input_ids.shape}")
        print(f"  attention_mask: {attention_mask.shape}")
        print(f"  position_ids: {position_ids.shape}")
        print(f"  past_key_values length: {len(past_key_values)}")
        for i, (k, v) in enumerate(past_key_values):
            print(f"    layer {i}: key={k.shape}, value={v.shape}")
        return

    # 导出 ONNX
    print("Exporting ONNX model...")

    torch.onnx.export(
        model,
        f=out_path,
        args=input_args,
        input_names=input_names,
        output_names=output_names,
        dynamic_axes=dynamic_axes,
        opset_version=13,
        export_params=True,
    )

if __name__ == "__main__":
    import os
    os.chdir(os.path.dirname(__file__))
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--model", "-m",
        type=str, 
        default="./TinyLlama-chat-v1.0", 
        help="transformers model"
    )
    parser.add_argument(
        "--output","-o",
        type=str,
        default="./model/export_out/TinyLlama-chat-v1.0-quant.onnx",
        help="where to save onnx model",
    )
    parser.add_argument(
        "--act-path","-a",
        type=str,
        default="./act/TinyLlama-chat-v1.0-act.pt",
        help="path to act_scales",
    )
    parser.add_argument(
        "--quant","-q",
        type=str,
        default="./config/w8x8.py",
        help="path to quant config",
    )
    args = parser.parse_args()
    export_onnx(args.model,args.output,args.quant,args.act_path)