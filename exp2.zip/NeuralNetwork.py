import math
from Operator import *

class DistilBertEmbeddings:
    def __init__(self, vocab_size, hidden_size, max_position_embeddings):
        self.word_embeddings = Embedding(vocab_size, hidden_size)
        self.position_embeddings = Embedding(max_position_embeddings, hidden_size)
        self.LayerNorm = LayerNorm(hidden_size)

    def __call__(self, input_ids):
        seq_len = input_ids.shape[1]
        position_ids = np.arange(seq_len)[None, :]
        word_emb = self.word_embeddings(input_ids)
        pos_emb = self.position_embeddings(position_ids)
        embeddings = word_emb + pos_emb
        output = self.LayerNorm(embeddings)
        return output

class MultiHeadSelfAttention:
    def __init__(self, hidden_size, num_heads):
        assert hidden_size % num_heads == 0
        self.num_heads = num_heads
        self.head_dim = hidden_size // num_heads

        self.q_lin = Linear(hidden_size, hidden_size)
        self.k_lin = Linear(hidden_size, hidden_size)
        self.v_lin = Linear(hidden_size, hidden_size)
        self.out_lin = Linear(hidden_size, hidden_size)

    def __call__(self, x, mask=None):
        bsz, seq_len, hidden = x.shape
        # TODO：同理，实现 k、v 的 reshape
        q = self.q_lin(x).reshape(bsz, seq_len, self.num_heads, self.head_dim).transpose(0, 2, 1, 3)
        k = self.k_lin(x).reshape(bsz, seq_len, self.num_heads, self.head_dim).transpose(0, 2, 1, 3)  
        v = self.v_lin(x).reshape(bsz, seq_len, self.num_heads, self.head_dim).transpose(0, 2, 1, 3)
        # TODO：Scaled Dot-Product，计算注意力分数 scores，注意张量的各个维度
        #     hint：在矩阵乘法时，首先要理解清楚两个输入矩阵和输出矩阵的维度
        scores = np.matmul(q, k.transpose(0, 1, 3, 2)) / np.sqrt(self.head_dim)
        # TODO: Mask
        if mask is not None:
            mask = mask[:, None, None, :]  
            scores = scores + (1.0 - mask) * -1e9
        # TODO：Softmax
        attention_weights = softmax(scores, axis=-1)
        # 这里如果不仅做前向推理，Dropout 需要参与计算
        # TODO：Weighted Sum
        context = np.matmul(attention_weights, v)
        # TODO：拼接所有头并通过线性层
        context = context.transpose(0, 2, 1, 3).reshape(bsz, seq_len, hidden)
        return self.out_lin(context)

class TransformerBlock:
    def __init__(self, hidden_size, num_heads, dim_ff):
        self.attention = MultiHeadSelfAttention(hidden_size, num_heads)
        self.sa_layer_norm = LayerNorm(hidden_size)
        self.ff1 = Linear(hidden_size, dim_ff)
        self.ff2 = Linear(dim_ff, hidden_size)
        self.output_layer_norm = LayerNorm(hidden_size)

    def __call__(self, x, mask=None):
        # 自注意力 + 残差连接
        normed_x = self.sa_layer_norm(x)
        attention_output = self.attention(normed_x, mask)
        x1 = x + attention_output  # 残差连接
        
        # 前馈网络 + 残差连接
        normed_x1 = self.output_layer_norm(x1)
        ff_output = self.ff2(gelu(self.ff1(normed_x1)))
        output = x1 + ff_output  # 残差连接
        
        return output


class DistilBertEncoder:
    def __init__(self, num_layers, hidden_size, num_heads, dim_ff):
        self.layers = [
            TransformerBlock(hidden_size, num_heads, dim_ff) 
            for _ in range(num_layers)
        ]

    def __call__(self, x, mask=None):
        for layer in self.layers:
            x = layer(x, mask)
        return x
        

class DistilBertModel:
    def __init__(self, vocab_size, hidden_size, num_layers, num_heads, dim_ff, 
                 max_position_embeddings):
        self.embeddings = DistilBertEmbeddings(vocab_size, hidden_size, max_position_embeddings)
        self.encoder = DistilBertEncoder(num_layers, hidden_size, num_heads, dim_ff)
    
    def __call__(self, input_ids, attention_mask=None):
        
        embeddings = self.embeddings(input_ids)
        
        encoder_output = self.encoder(embeddings, attention_mask)
        
        return encoder_output

class DistilBertForSequenceClassification:
    def __init__(self, vocab_size, hidden_size, num_layers, num_heads, dim_ff, max_position_embeddings, num_labels):
        self.distilbert = DistilBertModel(vocab_size, hidden_size, num_layers, num_heads, dim_ff, max_position_embeddings)
        self.pre_classifier = Linear(hidden_size, hidden_size)
        self.classifier = Linear(hidden_size, num_labels)

    def __call__(self, input_ids, attention_mask=None):
        hidden_states = self.distilbert(input_ids, attention_mask)
        pooled_output = hidden_states[:, 0]
        pooled_output = np.maximum(self.pre_classifier(pooled_output), 0)  # ReLU
        logits = self.classifier(pooled_output)
        return logits