import numpy as np
def gelu(x):
    return 0.5 * x * (1.0 + np.tanh(np.sqrt(2.0 / np.pi) * (x + 0.044715 * np.power(x, 3))))

class Embedding:
    def __init__(self, vocab_size, hidden_size):
        self.weight = np.zeros((vocab_size, hidden_size))

    def __call__(self, x): # 定义此 magic method 后，可通过类似函数的方式调用实例
        return self.weight[x]

class LayerNorm:
    def __init__(self, hidden_size, eps=1e-12):
        self.gamma = np.ones(hidden_size)
        self.beta = np.zeros(hidden_size)
        self.eps = eps

    def __call__(self, x):
        # TODO: LN
        mean = np.mean(x, axis=-1, keepdims=True)
        var = np.var(x, axis=-1, keepdims=True)
        normed = (x - mean) / np.sqrt(var + self.eps)
        result = self.gamma * normed + self.beta
        return result

class Linear:
    def __init__(self, in_dim, out_dim):
        self.weight = np.zeros((in_dim, out_dim))
        self.bias = np.zeros(out_dim)

    def __call__(self, x):
        # TODO: Linear
        
        return np.dot(x, self.weight) + self.bias


def softmax(x, axis=-1):
    x_max = np.max(x, axis=axis, keepdims=True)
    exp_x = np.exp(x - x_max)
    return exp_x / np.sum(exp_x, axis=axis, keepdims=True)