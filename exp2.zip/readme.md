由于部分数据集和模型权重比较大，未放入压缩包中，请在以下共享资料库中下载：
https://box.nju.edu.cn/d/ace92b2c60bf4459bfab/


代码执行方式：
`python exp2.py`