import numpy as np
import torch
from transformers import DistilBertTokenizer
from datasets import load_dataset
from tqdm import tqdm
from NeuralNetwork import DistilBertForSequenceClassification


# 加载权重
def load_torch_weights_into_numpy(np_model, state_dict):
    # Embeddings
    np_model.distilbert.embeddings.word_embeddings.weight = state_dict["distilbert.embeddings.word_embeddings.weight"].cpu().numpy()
    np_model.distilbert.embeddings.position_embeddings.weight = state_dict["distilbert.embeddings.position_embeddings.weight"].cpu().numpy()
    np_model.distilbert.embeddings.LayerNorm.gamma = state_dict["distilbert.embeddings.LayerNorm.weight"].cpu().numpy()
    np_model.distilbert.embeddings.LayerNorm.beta = state_dict["distilbert.embeddings.LayerNorm.bias"].cpu().numpy()

    # Transformer layers
    for i, layer in enumerate(np_model.distilbert.encoder.layers):
        prefix = f"distilbert.transformer.layer.{i}."

        # Attention
        layer.attention.q_lin.weight = state_dict[prefix + "attention.q_lin.weight"].cpu().numpy().T
        layer.attention.q_lin.bias = state_dict[prefix + "attention.q_lin.bias"].cpu().numpy()
        layer.attention.k_lin.weight = state_dict[prefix + "attention.k_lin.weight"].cpu().numpy().T
        layer.attention.k_lin.bias = state_dict[prefix + "attention.k_lin.bias"].cpu().numpy()
        layer.attention.v_lin.weight = state_dict[prefix + "attention.v_lin.weight"].cpu().numpy().T
        layer.attention.v_lin.bias = state_dict[prefix + "attention.v_lin.bias"].cpu().numpy()
        layer.attention.out_lin.weight = state_dict[prefix + "attention.out_lin.weight"].cpu().numpy().T
        layer.attention.out_lin.bias = state_dict[prefix + "attention.out_lin.bias"].cpu().numpy()
        layer.sa_layer_norm.gamma = state_dict[prefix + "sa_layer_norm.weight"].cpu().numpy()
        layer.sa_layer_norm.beta = state_dict[prefix + "sa_layer_norm.bias"].cpu().numpy()

        # FFN
        layer.ff1.weight = state_dict[prefix + "ffn.0.weight"].cpu().numpy().T
        layer.ff1.bias = state_dict[prefix + "ffn.0.bias"].cpu().numpy()
        layer.ff2.weight = state_dict[prefix + "ffn.3.weight"].cpu().numpy().T
        layer.ff2.bias = state_dict[prefix + "ffn.3.bias"].cpu().numpy()
        layer.output_layer_norm.gamma = state_dict[prefix + "output_layer_norm.weight"].cpu().numpy()
        layer.output_layer_norm.beta = state_dict[prefix + "output_layer_norm.bias"].cpu().numpy()

    # Classifier
    np_model.pre_classifier.weight = state_dict["pre_classifier.weight"].cpu().numpy().T
    np_model.pre_classifier.bias = state_dict["pre_classifier.bias"].cpu().numpy()
    np_model.classifier.weight = state_dict["classifier.weight"].cpu().numpy().T
    np_model.classifier.bias = state_dict["classifier.bias"].cpu().numpy()


if __name__ == "__main__":
    vocab_size = 30522
    hidden_size = 768
    num_layers = 6
    num_heads = 12
    dim_ff = 3072
    max_position_embeddings = 512
    num_labels = 4

    np_model = DistilBertForSequenceClassification(
        vocab_size, hidden_size, num_layers, num_heads, dim_ff, max_position_embeddings, num_labels
    )
    state_dict = torch.load("./distilbert_agnews.pt", map_location="cpu")
    load_torch_weights_into_numpy(np_model, state_dict)
    
    tokenizer = DistilBertTokenizer.from_pretrained("./distilbert-base-uncased")
    dataset = load_dataset("./ag_news")

    def encode_batch(batch):
        return tokenizer(batch["text"], truncation=True, padding="max_length", max_length=128)

    encoded_dataset = dataset.map(encode_batch, batched=True)
    test_input_ids = np.array(encoded_dataset["test"]["input_ids"])
    test_attention_mask = np.array(encoded_dataset["test"]["attention_mask"])
    test_labels = np.array(encoded_dataset["test"]["label"])
    correct, total = 0, 0
    batch_size = 32

    for i in tqdm(range(0, 160, batch_size)):
        input_ids = test_input_ids[i:i+batch_size]
        attention_mask = test_attention_mask[i:i+batch_size]
        labels = test_labels[i:i+batch_size]

        logits = np_model(input_ids, attention_mask)
        preds = np.argmax(logits, axis=-1)

        correct += (preds == labels).sum()
        total += len(labels)

    print(f"Accuracy: {correct/total:.4f}")
