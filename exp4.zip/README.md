
```
submit
├─ 231220069_杨力泉_实验4报告.pdf
├─ src
│  ├─ check_config.py
│  ├─ generate.py
│  ├─ src
│  │  ├─ chinese_char_tokenizer.py
│  │  ├─ dataset.py
│  │  ├─ model.py
│  │  ├─ preprocess.py
│  │  ├─ utils.py
│  │  └─ __pycache__
│  │     ├─ chinese_char_tokenizer.cpython-310.pyc
│  │     ├─ dataset.cpython-310.pyc
│  │     ├─ model.cpython-310.pyc
│  │     └─ utils.cpython-310.pyc
│  ├─ test_all.py
│  ├─ train.py
│  ├─ trainback.py
│  └─ train_optimized.py
└─ training_opt (2).log

```