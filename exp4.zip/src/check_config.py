# check_config.py
"""
检查训练和推理配置一致性
"""
import sys
import os

# 添加项目路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from src.model import GPT, GPTConfig
from src.chinese_char_tokenizer import ChineseCharTokenizer

VOCAB_SIZE = 5424

def check_configs():
    """检查训练和推理配置是否一致"""
    
    print("=== 配置一致性检查 ===")
    
    # 1. 训练配置（根据 train.py）
    train_vocab_size = (VOCAB_SIZE // 64 + 1) * 64
    train_config = GPTConfig(vocab_size=train_vocab_size)
    
    print(f"训练配置:")
    print(f"  词表大小: {train_config.vocab_size} (原始: {VOCAB_SIZE})")
    print(f"  序列长度: {train_config.block_size}")
    print(f"  层数: {train_config.n_layer}")
    print(f"  注意力头数: {train_config.n_head}")
    print(f"  嵌入维度: {train_config.n_embd}")
    print(f"  Dropout: {train_config.dropout}")
    print(f"  偏置: {train_config.bias}")
    
    # 2. 推理配置（根据 generate.py）
    infer_config = GPTConfig(vocab_size=(VOCAB_SIZE // 64 + 1) * 64)
    
    print(f"\n推理配置:")
    print(f"  词表大小: {infer_config.vocab_size}")
    
    # 3. 检查一致性
    configs_match = (
        train_config.vocab_size == infer_config.vocab_size and
        train_config.block_size == infer_config.block_size and
        train_config.n_layer == infer_config.n_layer and
        train_config.n_head == infer_config.n_head and
        train_config.n_embd == infer_config.n_embd
    )
    
    if configs_match:
        print(f"\n✅ 训练和推理配置一致")
    else:
        print(f"\n❌ 训练和推理配置不一致!")
        print(f"差异:")
        if train_config.vocab_size != infer_config.vocab_size:
            print(f"  词表大小: 训练={train_config.vocab_size}, 推理={infer_config.vocab_size}")
        if train_config.block_size != infer_config.block_size:
            print(f"  序列长度: 训练={train_config.block_size}, 推理={infer_config.block_size}")
        if train_config.n_layer != infer_config.n_layer:
            print(f"  层数: 训练={train_config.n_layer}, 推理={infer_config.n_layer}")
        if train_config.n_head != infer_config.n_head:
            print(f"  注意力头数: 训练={train_config.n_head}, 推理={infer_config.n_head}")
        if train_config.n_embd != infer_config.n_embd:
            print(f"  嵌入维度: 训练={train_config.n_embd}, 推理={infer_config.n_embd}")
    
    # 4. 检查分词器
    print(f"\n=== 分词器检查 ===")
    try:
        tokenizer = ChineseCharTokenizer.load("./dataset/chinese_char_tokenizer.json")
        vocab_info = tokenizer.get_vocab_info()
        print(f"Tokenizer 词表大小: {vocab_info['actual_vocab_size']}")
        print(f"模型词表大小: {train_config.vocab_size}")
        
        if vocab_info['actual_vocab_size'] <= train_config.vocab_size:
            print("✅ 分词器词表大小 <= 模型词表大小")
        else:
            print("⚠️  分词器词表大小 > 模型词表大小，可能出现 OOV")
    except Exception as e:
        print(f"加载分词器失败: {e}")
    
    # 5. 模型参数量估算
    print(f"\n=== 模型参数量估算 ===")
    model = GPT(train_config)
    total_params = model.get_num_params(non_embedding=False)
    non_embedding_params = model.get_num_params(non_embedding=True)
    
    print(f"总参数数量: {total_params:,}")
    print(f"非嵌入参数数量: {non_embedding_params:,}")
    
    # FP32 内存估算
    fp32_memory_mb = total_params * 4 / 1024 / 1024
    print(f"FP32 模型内存: {fp32_memory_mb:.2f} MB")
    
    # 训练时显存估算（粗略）
    # 假设 batch_size=12, seq_len=256
    batch_size = 12
    seq_len = 256
    activation_memory_mb = batch_size * seq_len * train_config.n_embd * train_config.n_layer * 4 / 1024 / 1024
    print(f"训练时激活内存估算 (batch_size={batch_size}, seq_len={seq_len}): {activation_memory_mb:.2f} MB")
    
    return configs_match

if __name__ == "__main__":
    success = check_configs()
    sys.exit(0 if success else 1)