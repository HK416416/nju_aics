"""
实验四：GPT模型完整测试脚本 - 修复版本
测试所有需要我们实现的部分
包括：模型结构、数据预处理、训练、推理
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import numpy as np
import mindspore as ms
import mindspore.nn as nn
import mindspore.ops as ops
from mindspore import context, Tensor
from mindspore.common.initializer import Normal, initializer

# 设置运行环境
context.set_context(mode=context.PYNATIVE_MODE, device_target="CPU")

# ==================== 1. 测试 LayerNorm ====================
print("=" * 60)
print("测试 1: LayerNorm")
print("=" * 60)

def test_layernorm():
    """测试自定义 LayerNorm"""
    print("1.1 测试 LayerNorm 前向传播...")
    
    # 创建 LayerNorm 层
    from src.model import LayerNorm
    ln = LayerNorm(512, bias=True)
    
    # 创建随机输入
    x = Tensor(np.random.randn(2, 10, 512), dtype=ms.float32)
    
    # 前向传播
    output = ln(x)
    
    print(f"   输入形状: {x.shape}")
    print(f"   输出形状: {output.shape}")
    print(f"   LayerNorm 权重形状: {ln.weight.shape}")
    print(f"   LayerNorm 偏置形状: {ln.bias.shape}")
    
    # 检查输出统计
    mean = output.mean().asnumpy()
    std = output.std().asnumpy()
    print(f"   输出均值: {mean:.6f} (接近 0)")
    print(f"   输出标准差: {std:.6f} (接近 1)")
    
    print("1.2 测试无偏置的 LayerNorm...")
    ln_no_bias = LayerNorm(512, bias=False)
    output_no_bias = ln_no_bias(x)
    print(f"   输出形状: {output_no_bias.shape}")
    print(f"   偏置为 None: {ln_no_bias.bias is None}")
    
    return True

# ==================== 2. 测试 MLP ====================
print("\n" + "=" * 60)
print("测试 2: MLP")
print("=" * 60)

def test_mlp():
    """测试 MLP"""
    print("2.1 测试 MLP 前向传播...")
    
    # 创建配置
    from src.model import MLP, GPTConfig
    config = GPTConfig(
        n_embd=512,
        dropout=0.1,
        bias=True
    )
    
    # 创建 MLP
    mlp = MLP(config)
    
    # 创建随机输入
    x = Tensor(np.random.randn(2, 10, 512), dtype=ms.float32)
    
    # 前向传播
    output = mlp(x)
    
    print(f"   输入形状: {x.shape}")
    print(f"   输出形状: {output.shape}")
    print(f"   隐藏层维度: {mlp.c_fc.out_channels}")
    print(f"   激活函数: {type(mlp.activation).__name__}")
    
    # 检查参数
    params = list(mlp.get_parameters())
    print(f"   总参数数量: {len(params)}")
    for i, param in enumerate(params):
        print(f"     参数 {i}: {param.name}, 形状: {param.shape}")
    
    return True

# ==================== 3. 测试 CausalSelfAttention ====================
print("\n" + "=" * 60)
print("测试 3: CausalSelfAttention")
print("=" * 60)

def test_attention():
    """测试因果自注意力"""
    print("3.1 测试注意力前向传播...")
    
    # 创建配置
    from src.model import CausalSelfAttention, GPTConfig
    config = GPTConfig(
        n_embd=512,
        n_head=8,
        dropout=0.1,
        bias=True
    )
    
    # 创建注意力层
    attn = CausalSelfAttention(config)
    
    # 创建随机输入
    x = Tensor(np.random.randn(2, 16, 512), dtype=ms.float32)
    
    # 前向传播
    output = attn(x)
    
    print(f"   输入形状: {x.shape}")
    print(f"   输出形状: {output.shape}")
    print(f"   注意力头数: {attn.n_head}")
    print(f"   每个头的维度: {attn.head_dim}")
    
    # 检查参数
    params = list(attn.get_parameters())
    print(f"   总参数数量: {len(params)}")
    
    print("3.2 测试因果掩码...")
    # 创建一个小输入来验证因果性
    small_x = Tensor(np.random.randn(1, 4, 512), dtype=ms.float32)
    small_output = attn(small_x)
    print(f"   小输入形状: {small_x.shape}")
    print(f"   小输出形状: {small_output.shape}")
    
    return True

# ==================== 4. 测试 Block ====================
print("\n" + "=" * 60)
print("测试 4: Transformer Block")
print("=" * 60)

def test_block():
    """测试 Transformer 块"""
    print("4.1 测试 Block 前向传播...")
    
    # 创建配置
    from src.model import Block, GPTConfig
    config = GPTConfig(
        n_embd=512,
        n_head=8,
        dropout=0.1,
        bias=True
    )
    
    # 创建 Block
    block = Block(config)
    
    # 创建随机输入
    x = Tensor(np.random.randn(2, 16, 512), dtype=ms.float32)
    
    # 前向传播
    output = block(x)
    
    print(f"   输入形状: {x.shape}")
    print(f"   输出形状: {output.shape}")
    
    # 检查块中的组件
    print(f"   包含 LayerNorm: {hasattr(block, 'ln_1')}")
    print(f"   包含注意力层: {hasattr(block, 'attn')}")
    print(f"   包含 MLP: {hasattr(block, 'mlp')}")
    
    return True

# ==================== 5. 测试 GPT 模型 ====================
print("\n" + "=" * 60)
print("测试 5: GPT 模型")
print("=" * 60)

def test_gpt():
    """测试完整 GPT 模型"""
    print("5.1 测试 GPT 模型初始化...")
    
    # 创建小配置用于测试
    from src.model import GPT, GPTConfig
    config = GPTConfig(
        vocab_size=1000,
        block_size=256,
        n_layer=4,      # 减少层数以加速测试
        n_head=4,
        n_embd=256,
        dropout=0.1,
        bias=True
    )
    
    # 创建 GPT 模型
    gpt = GPT(config)
    
    print(f"   词表大小: {config.vocab_size}")
    print(f"   最大序列长度: {config.block_size}")
    print(f"   Transformer 层数: {config.n_layer}")
    print(f"   注意力头数: {config.n_head}")
    print(f"   嵌入维度: {config.n_embd}")
    
    # 测试参数数量
    total_params = gpt.get_num_params(non_embedding=False)
    non_embedding_params = gpt.get_num_params(non_embedding=True)
    print(f"   总参数数量: {total_params:,}")
    print(f"   非嵌入参数数量: {non_embedding_params:,}")
    
    print("\n5.2 测试 GPT 前向传播...")
    
    # 创建随机输入
    batch_size = 2
    seq_len = 32
    idx = Tensor(np.random.randint(0, config.vocab_size, (batch_size, seq_len)), dtype=ms.int32)
    
    # 前向传播（无目标）
    logits, loss = gpt(idx)
    
    print(f"   输入形状: {idx.shape}")
    print(f"   输出 logits 形状: {logits.shape}")
    print(f"   损失值: {loss} (应为 None)")
    
    print("\n5.3 测试 GPT 带目标的前向传播...")
    
    # 创建目标
    targets = Tensor(np.random.randint(0, config.vocab_size, (batch_size, seq_len)), dtype=ms.int32)
    
    # 前向传播（有目标）
    logits, loss = gpt(idx, targets)
    
    print(f"   目标形状: {targets.shape}")
    print(f"   损失值: {loss}")
    print(f"   损失类型: {type(loss)}")
    
    print("\n5.4 测试权重共享...")
    # 检查 lm_head 权重是否与 token 嵌入权重相同
    weight_shared = gpt.lm_head.weight is gpt.wte.embedding_table
    print(f"   lm_head 权重与 token 嵌入权重共享: {weight_shared}")
    
    return True

# ==================== 6. 测试分词器 ====================
print("\n" + "=" * 60)
print("测试 6: 分词器")
print("=" * 60)

def test_tokenizer():
    """测试中文字符分词器"""
    print("6.1 测试分词器基础功能...")
    
    # 创建一个小词表用于测试
    from src.chinese_char_tokenizer import ChineseCharTokenizer
    vocab = ["<pad>", "<unk>", "<bos>", "<eos>"] + list("金庸武侠小说测试")
    
    # 创建分词器
    tokenizer = ChineseCharTokenizer(vocab)
    
    # 测试文本
    text = "金庸武侠小说"
    
    # 编码
    tokens = tokenizer.encode(text)
    print(f"   原始文本: {text}")
    print(f"   编码结果: {tokens}")
    print(f"   编码长度: {len(tokens)}")
    
    # 解码
    decoded_text = tokenizer.decode(tokens)
    print(f"   解码文本: {decoded_text}")
    print(f"   编码-解码一致性: {text == decoded_text}")
    
    print("\n6.2 测试特殊标记...")
    # 测试特殊标记编码
    bos_token = tokenizer.bos_id
    eos_token = tokenizer.eos_id
    print(f"   BOS token ID: {bos_token}")
    print(f"   EOS token ID: {eos_token}")
    
    # 测试特殊标记
    bos_text = tokenizer.decode([bos_token])
    eos_text = tokenizer.decode([eos_token])
    print(f"   BOS 文本: {bos_text}")
    print(f"   EOS 文本: {eos_text}")
    
    return True

# ==================== 7. 测试数据加载 ====================
print("\n" + "=" * 60)
print("测试 7: 数据加载")
print("=" * 60)

def test_dataset():
    """测试数据加载"""
    print("7.1 测试小说读取...")
    
    from src.utils import read_jinyong
    # 创建一个小测试文件
    test_dir = "./test_data"
    os.makedirs(test_dir, exist_ok=True)
    
    # 写入测试文本
    test_text = """话说天下大势，分久必合，合久必分。
周末七国分争，并入于秦。及秦灭之后，楚、汉分争，又并入于汉。"""
    
    test_file = os.path.join(test_dir, "test.txt")
    with open(test_file, "w", encoding="utf-8") as f:
        f.write(test_text)
    
    # 读取测试数据
    data = read_jinyong(test_dir)
    print(f"   读取字符数: {len(data)}")
    print(f"   前50个字符: {data[:50]}")
    
    print("\n7.2 测试 MindRecord 数据集创建...")
    
    # 注意：这个测试需要先运行数据预处理，这里只是测试数据集创建接口
    print("   (需要先运行 preprocess.py 生成 MindRecord 文件)")
    
    return True

# ==================== 8. 测试训练步骤 ====================
print("\n" + "=" * 60)
print("测试 8: 训练步骤")
print("=" * 60)

def test_training_step():
    """测试训练步骤"""
    print("8.1 测试损失计算...")
    
    # 创建小模型配置
    from src.model import GPT, GPTConfig, GPTWithLoss
    config = GPTConfig(
        vocab_size=1000,
        block_size=256,
        n_layer=2,
        n_head=2,
        n_embd=128,
        dropout=0.0,
        bias=True
    )
    
    # 创建模型和损失函数
    gpt = GPT(config)
    gpt_with_loss = GPTWithLoss(gpt)
    
    # 创建输入数据
    batch_size = 2
    seq_len = 32
    input_ids = Tensor(np.random.randint(0, config.vocab_size, (batch_size, seq_len)), dtype=ms.int32)
    
    # 计算损失
    loss = gpt_with_loss(input_ids)
    
    print(f"   输入形状: {input_ids.shape}")
    print(f"   计算损失: {loss}")
    
    print("\n8.2 测试优化器配置...")
    
    # 测试优化器配置
    optimizer = gpt.configure_optimizers(
        weight_decay=0.1,
        learning_rate=0.001,
        betas=(0.9, 0.95)
    )
    
    print(f"   优化器类型: {type(optimizer).__name__}")
    
    return True

# ==================== 9. 测试文本生成 ====================
print("\n" + "=" * 60)
print("测试 9: 文本生成")
print("=" * 60)

def test_generation():
    """测试文本生成"""
    print("9.1 测试生成函数...")
    
    # 创建小模型配置
    from src.model import GPT, GPTConfig
    config = GPTConfig(
        vocab_size=100,
        block_size=64,
        n_layer=2,
        n_head=2,
        n_embd=64,
        dropout=0.0,
        bias=True
    )
    
    # 创建模型
    gpt = GPT(config)
    
    # 设置评估模式
    gpt.set_train(False)
    
    # 创建起始序列
    start_seq = Tensor([[1, 2, 3, 4, 5]], dtype=ms.int32)  # 简单的测试序列
    
    print(f"   起始序列形状: {start_seq.shape}")
    print(f"   起始序列: {start_seq[0].asnumpy().tolist()}")
    
    print("\n9.2 测试不同温度下的生成...")
    
    # 测试不同参数
    max_new_tokens = 10
    
    print("   a) 温度=1.0, top_k=None")
    try:
        output1 = gpt.generate(start_seq, max_new_tokens=max_new_tokens, temperature=1.0, top_k=None)
        print(f"      输出形状: {output1.shape}")
        print(f"      输出: {output1[0].asnumpy().tolist()[:15]}...")
    except Exception as e:
        print(f"      生成失败: {e}")
    
    print("   b) 温度=0.8, top_k=10")
    try:
        output2 = gpt.generate(start_seq, max_new_tokens=max_new_tokens, temperature=0.8, top_k=10)
        print(f"      输出形状: {output2.shape}")
        print(f"      输出: {output2[0].asnumpy().tolist()[:15]}...")
    except Exception as e:
        print(f"      生成失败: {e}")
    
    return True

# ==================== 10. 测试工具函数 ====================
print("\n" + "=" * 60)
print("测试 10: 工具函数")
print("=" * 60)

def test_utils():
    """测试工具函数"""
    print("10.1 测试学习率调度器...")
    
    from src.utils import LearningRate
    
    # 创建学习率调度器
    lr_scheduler = LearningRate(
        learning_rate=0.001,
        min_lr=0.0001,
        warmup_steps=100,
        decay_steps=1000
    )
    
    # 测试不同步骤的学习率
    steps = [0, 50, 100, 500, 1000]
    for step in steps:
        lr = lr_scheduler(step)
        # 转换为 Python 浮点数
        if hasattr(lr, 'asnumpy'):
            lr_value = float(lr.asnumpy())
        else:
            lr_value = float(lr)
        print(f"   步骤 {step}: 学习率 = {lr_value:.6f}")
    
    return True

# ==================== 主测试函数 ====================

def main():
    """运行所有测试"""
    print("开始测试实验四所有实现部分")
    print("=" * 60)
    
    test_results = {}
    
    try:
        # 测试 1: LayerNorm
        test_results["LayerNorm"] = test_layernorm()
    except Exception as e:
        print(f"LayerNorm 测试失败: {e}")
        import traceback
        traceback.print_exc()
        test_results["LayerNorm"] = False
    
    try:
        # 测试 2: MLP
        test_results["MLP"] = test_mlp()
    except Exception as e:
        print(f"MLP 测试失败: {e}")
        test_results["MLP"] = False
    
    try:
        # 测试 3: CausalSelfAttention
        test_results["CausalSelfAttention"] = test_attention()
    except Exception as e:
        print(f"CausalSelfAttention 测试失败: {e}")
        test_results["CausalSelfAttention"] = False
    
    try:
        # 测试 4: Block
        test_results["Block"] = test_block()
    except Exception as e:
        print(f"Block 测试失败: {e}")
        test_results["Block"] = False
    
    try:
        # 测试 5: GPT 模型
        test_results["GPT"] = test_gpt()
    except Exception as e:
        print(f"GPT 测试失败: {e}")
        test_results["GPT"] = False
    
    try:
        # 测试 6: 分词器
        test_results["Tokenizer"] = test_tokenizer()
    except Exception as e:
        print(f"Tokenizer 测试失败: {e}")
        test_results["Tokenizer"] = False
    
    try:
        # 测试 7: 数据加载
        test_results["Dataset"] = test_dataset()
    except Exception as e:
        print(f"Dataset 测试失败: {e}")
        test_results["Dataset"] = False
    
    try:
        # 测试 8: 训练步骤
        test_results["Training"] = test_training_step()
    except Exception as e:
        print(f"Training 测试失败: {e}")
        test_results["Training"] = False
    
    try:
        # 测试 9: 文本生成
        test_results["Generation"] = test_generation()
    except Exception as e:
        print(f"Generation 测试失败: {e}")
        test_results["Generation"] = False
    
    try:
        # 测试 10: 工具函数
        test_results["Utils"] = test_utils()
    except Exception as e:
        print(f"Utils 测试失败: {e}")
        test_results["Utils"] = False
    
    # 清理测试数据
    import shutil
    if os.path.exists("./test_data"):
        shutil.rmtree("./test_data")
    
    # 打印测试结果汇总
    print("\n" + "=" * 60)
    print("测试结果汇总")
    print("=" * 60)
    
    passed = 0
    total = len(test_results)
    
    for test_name, result in test_results.items():
        status = "✓ 通过" if result else "✗ 失败"
        print(f"  {test_name:25} {status}")
        if result:
            passed += 1
    
    print("\n" + "=" * 60)
    print(f"总测试数: {total}, 通过: {passed}, 失败: {total - passed}")
    
    if passed == total:
        print("🎉 所有测试通过！")
        return 0
    else:
        print("⚠️  部分测试失败，请检查实现")
        return 1

if __name__ == "__main__":
    # 设置随机种子以确保可重复性
    ms.set_seed(2025)
    np.random.seed(2025)
    
    # 运行测试
    exit_code = main()
    sys.exit(exit_code)