import numpy as np


class FullyConnectLayer:
    def __init__(self, in_features, out_features, has_bias=True):
        # 初始化权重和偏置
        self.weight = np.random.normal(loc=0, scale=0.01, size=(out_features, in_features))
        self.bias = np.zeros(out_features) if has_bias else None
        self.has_bias = has_bias

        self.inputs = None
        self.grad_weight = None
        self.grad_bias = None

    def forward(self, inputs):
        # TODO: 根据公式编写全连接层的前向传播过程
        # 前向传播: Y = XW^T + b
        self.inputs = inputs
        outputs = np.dot(inputs, self.weight.T)
        if (self.has_bias == True):
            outputs += self.bias
        return outputs
        

    def backward(self, in_grad):
        # TODO: 根据公式编写全连接层的反向传播过程
        # 计算权重梯度: ∇W L = X^T ∇Y L
        self.grad_weight = np.dot(self.inputs.T, in_grad)
        
        # 计算偏置梯度: ∇b L = sum(∇Y L, axis=0)
        if self.has_bias:
            self.grad_bias = np.sum(in_grad, axis=0)
        
        # 计算输入梯度: ∇X L = ∇Y L W
        out_grad = np.dot(in_grad, self.weight)
        return out_grad

    def update_params(self, lr):
        # TODO: 根据公式编写全连接层的参数更新过程

        self.weight -= lr * self.grad_weight.T
        if self.has_bias:
            self.bias -= lr * self.grad_bias

    def load_params(self, weight, bias):
        # 加载权重和偏置
        assert self.weight.shape == weight.shape
        self.weight = weight
        if self.has_bias:
            assert self.bias.shape == bias.shape
            self.bias = bias


class ReluLayer:
    def __init__(self):
        self.inputs = None

    def forward(self, inputs):
        # TODO: 根据公式编写激活函数ReLU的前向传播过程
        self.inputs = inputs
        return np.maximum(0, inputs)

    def backward(self, in_grad):
        out_grad = in_grad.copy()
        out_grad[self.inputs < 0] = 0  
        return out_grad

class SigmoidLayer:
    def __init__(self):
        self.outputs = None
    
    def forward(self, inputs):
        outputs = np.zeros_like(inputs)
        #数值过大和过小的时候会由于浮点数的精确度的问题而数据失效，姑
        neg_mask = inputs < -20
        outputs[neg_mask] = 0.0
        pos_mask = inputs > 20
        outputs[pos_mask] = 1.0
        mid_mask = ~(neg_mask | pos_mask)
        outputs[mid_mask] = 1.0 / (1.0 + np.exp(-inputs[mid_mask]))
        self.outputs = outputs
        return outputs
    
    def backward(self, in_grad):
        sigmoid_derivative = self.outputs * (1 - self.outputs)
        out_grad = in_grad * sigmoid_derivative
        return out_grad



class CrossEntropy:
    def __init__(self, dim=1):
        self.softmax_out = None
        self.label_onehot = None
        self.batch_size = None
        self.dim = dim

    def _softmax(self, inputs, dim=1):
        # TODO: 根据公式编写 Softmax 函数的前向传播过程
        exp_inputs = np.exp(inputs)
        softmax_out = exp_inputs / np.sum(exp_inputs, axis=dim, keepdims=True)
        return softmax_out

    def forward(self, inputs, labels):
        # TODO: 根据公式编写交叉熵损失函数的前向传播过程
        self.batch_size = inputs.shape[0]
        self.softmax_out = self._softmax(inputs, self.dim)
        self.label_onehot = np.zeros_like(self.softmax_out)
        self.label_onehot[np.arange(self.batch_size), labels] = 1.0
        loss = -np.sum(self.label_onehot * np.log(self.softmax_out + 1e-10)) / self.batch_size  # +1e-10避免log(0)
        return loss

    def backward(self, in_grad):
        # TODO: 根据公式编写交叉熵损失函数的反向传播过程
        return (self.softmax_out - self.label_onehot) / self.batch_size
